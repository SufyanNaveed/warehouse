<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('layout/header');
?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <h5>
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url('auth/dashboard'); ?>"><i class="fa fa-dashboard"></i>  Dashboard </a></li>
          <li><a href="<?php echo base_url('activation'); ?>">Activation</a></li>
        </ol>
      </h5>    
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
      <!-- right column -->
        <?php $this->load->view('suggestion.php'); ?>
        <?php 
          $this->load->view('layout/setting_sidebar');
        ?>
        <div class="col-md-9">
          <?php
            if($fail = $this->session->flashdata('failure')){
          ?>
              <div class="alert alert-danger message">
                <button class="close" data-dismiss="alert" type="button">×</button>
                  <?php echo $fail; ?>
                <div class="alerts-con"></div>
              </div>
          <?php
            }
          ?>
          <?php
            if($success = $this->session->flashdata('success')){
          ?>
              <div class="alert alert-success message">
                <button class="close" data-dismiss="alert" type="button">×</button>
                  <?php echo $success; ?>
                <div class="alerts-con"></div>
              </div>
          <?php
            }
          ?>
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Activation Details</h3>
            </div>
            <div class="box-body">
              <form role="form" id="form" method="post" action="<?php echo base_url('activation/index');?>">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="activation_key">Activation Key <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="activation_key" name="activation_key" 
                    value="<?php 
                              if(isset($activation) && $activation != null)
                              {
                                echo $activation->activation_key;
                              }                       
                          ?>" onblur="checkLength(this)"  maxlength="36">
                    <span class="validation-color" id="err_activation_key"><?php echo form_error('activation_key'); ?></span>
                  </div>
                  <div class="form-group">
                    <label for="email">Email <span class="validation-color">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" 
                    value="<?php 
                              if(isset($activation) && $activation != null)
                              {
                                echo $activation->email;
                              }                       
                           ?>">
                    <span class="validation-color" id="err_email"><?php echo form_error('email'); ?></span>
                  </div>
                  <div class="form-group">
                    <label for="status">Status <span class="validation-color">*</span></label><br/>
                    <span>
                    <?php 
                        if(isset($activation) && $activation != null)
                        {
                          if($activation->status == 100)
                            echo "Activated";
                          else if($activation->status == 101)
                            echo "In valid Application Key is used : This application will stop working soon";
                          else if($activation->status == 104)
                            echo "Activation Key is not valid.";
                        }
                        else
                        {
                          echo "Activation key is not available";
                        }                       
                     ?>
                    </span>
                    <span class="validation-color" id="err_email"><?php echo form_error('email'); ?></span>
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="box-footer">
                    <button type="submit" id="submit" class="btn btn-info">&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('discount_label_add'); ?>&nbsp;&nbsp;&nbsp;</button>
                    <span class="btn btn-default" id="cancel" style="margin-left: 2%" onclick="cancel('activation')"><!-- Cancel --> <?php echo $this->lang->line('discount_label_cancel'); ?></span>
                  </div>
                </div>
              </form>
            </div>
            <div class="box-body">
              <div class="alert alert-info alert-dismissible">
                <!-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> -->
                <h4><i class="icon fa fa-info"></i> Notes!</h4>
                <ol>
                  <li>If you don't have activation key and already purchased software then please drop mail at <b style="text-decoration: underline;">invento-purchase@vaksys.com</b> with Transaction Details</li>
                  <li>If user share his activation key with anyone else, application will stop working at any time and there are chances that user will lost the data which are saved in application.</li>
                  <li>If you want to purchase more than one licence, please contact the developer.</li>
                  <li>For bulk activation key purchase, you can submit ticket  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script type="text/javascript">
  function checkLength(el) {
    if (el.value.length != 36) {
      alert("#err_"+el.id);
      document.getElementById('err_'+el.id).textContent="Activation key must be exactly 36 characters";
    }
  }
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#submit").click(function(event){
        var email_regex     = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var activation_key  = $("#activation_key").val();
        var email           = $("#email").val();

        if(activation_key==null || activation_key=="")
        {
          $("#err_activation_key").text("Please enter Activation Key");
          return false;
        }
        else
        {
          $("#err_activation_key").text("");
        }

        if(email==null || email=="")
        {
          $("#err_email").text("Please enter email");
          return false;
        }
        else if(!email.match(email_regex))
        {
          $("#err_email").text("Please valid email");
        }
        else
        {
          $("#err_email").text("");
        }
    });

  });
</script>
<?php
  $this->load->view('layout/footer');
?>
<!-- <script>
  $(document).ready(function(){
    var discount_type_select = "Please Select Discount Type";
    var discount_amount_empty = "Please Enter Discount Amount";
    var discount_amount_invalid = "Please Enter Valid Discount Amount (Ex.2000)";
    $("#discount_type").change(function(event){
        var discount_type = $('#discount_type').val();
        $("#err_discount_value").text(""); // remove discount value if select percentage
        if(discount_type == "" || discount_type == null){
          $("#err_discount_type").text(discount_type_select);
          return false;
        }
        else{
          $("#err_discount_type").text("");
        }
        if(discount_type=="Fixed"){
          $('.discount_amount').show();
          $('.percentage_icon').text('.00');
        }
        else{
          $('.discount_amount').hide();
          $('.percentage_icon').text('%');
        }
    });
    $('#discount_amount').change(function(){
      value_regex = /^\$?[0-9]+(\.[0-9][0-9])?$/;
      var discount_amount = $('#discount_amount').val();
      if(discount_amount == "" || discount_amount == null){
        $('#err_ddiscount_amount').text(discount_amount_empty);
      }
      else{
        $('#err_discount_amount').text("");
      }
      if(!discount_amount.match(value_regex)){
        $('#err_ddiscount_amount').text(discount_amount_invalid);
      }
      else{
         $('#err_discount_amount').text("");
      }
    });
  });
</script> -->
<script>
  $(document).ready(function(){
    $("#submit").click(function(event){
      var name_regex = /^[-a-zA-Z\s]+$/;
      // var dvalue_regex = /^\$?[0-9]*([0-9]+)?$/;
      var dvalue_regex = ^[+-]?([0-9]*[.])?[0-9]+$;
      
      /*var discount_type = $('#discount_type').val();*/
      var discount_name = $('#discount_name').val();
      var discount_value = $('#discount_value').val();
      /*var discount_amount = $('#discount_amount').val();*/

       /* if(discount_type==""){
          $("#err_discount_type").text("Select the Discount Type.");
          return false;
        }
        else{
          $("#err_discount_type").text("");
        }*/
//Discount type validation complite.
        /*if(discount_type == "Fixed"){
          if(discount_amount==null || discount_amount==""){
            $("#err_discount_amount").text("Please Enter Amount.");
            $('#discount_amount').focus();
            return false;
          }
          else{
            $("#err_discount_amount").text("");
          }
          if (!discount_amount.match(dvalue_regex) ) {
            $('#err_discount_amount').text("  Please Enter Valid Amount. Ex(1000 or 1000.10)");   
            $('#discount_amount').focus();
            return false;
          }
          else{
            $("#err_discount_amount").text("");
          }
        }*/
        
//discount amount validation complite. 

        if(discount_name==null || discount_name==""){
          $("#err_discount_name").text("Please Enter Discount Name.");
          $('#discount_name').focus();
          return false;
        }
        else{
          $("#err_discount_name").text("");
        }
        if (!discount_name.match(name_regex) ) {
          $('#err_discount_name').text("  Please Enter Valid Discount Name ");  
          $('#discount_name').focus(); 
          return false;
        }
        else{
          $("#err_discount_name").text("");
        }
//discount name validation complite.
  
        if(discount_value==null || discount_value==""){
          $("#err_discount_value").text("Please Enter Discount Value.");
          $('#discount_value').focus();
          return false;
        }
        else{
          $("#err_discount_value").text("");
        }
        if (!discount_value.match(dvalue_regex) ) {
          $('#err_discount_value').text(" Please Enter Valid Discount Value. Ex(10) "); 
          $('#discount_value').focus();  
          return false;
        }
        else{
          $("#err_discount_value").text("");
        }
//discount value validation complite.
        
    });

    /*$("#discount_type").change(function(event){
        var discount_type = $('#discount_type').val();
        $("#err_discount_value").text(""); // remove discount value if select percentage
        if(discount_type=="Select Type"){
          $("#err_discount_type").text("Select the Discount Type.");
          return false;
        }
        else{
          $("#err_discount_type").text("");
        }
        if(discount_type=="Fixed"){
          $('.discount_amount').show();
        }
        else{
          $('.discount_amount').hide();
          $('.percentage_icon').text('%');
        }
    });*/
    /*$("#discount_amount").on("blur keyup",  function (event){
        var dvalue_regex = /^\$?[1-9][0-9]*(\.[0-9][0-9])?$/;
        var discount_amount = $('#discount_amount').val();
         if(discount_amount==null || discount_amount==""){
          $("#err_discount_amount").text("Please Enter Amount.");
          return false;
        }
        else{
          $("#err_discount_amount").text("");
        }
        if (!discount_amount.match(dvalue_regex) ) {
          $('#err_discount_amount').text("  Please Enter Valid Amount. Ex(1000 or 1000.10)");   
          return false;
        }
        else{
          $("#err_discount_amount").text("");
        }
    });*/
    $("#discount_name").on("blur keyup",  function (event){
        var name_regex = /^[-a-zA-Z\s]+$/;
        var discount_name = $('#discount_name').val();
        if(discount_name==null || discount_name==""){
          $("#err_discount_name").text("Please Enter Discount Name.");
          return false;
        }
        else{
          $("#err_discount_name").text("");
        }
        if (!discount_name.match(name_regex) ) {
          $('#err_discount_name').text("  Please Enter Valid Discount Name ");   
          return false;
        }
        else{
          $("#err_discount_name").text("");
        }
    });

    $("#discount_value").on("blur keyup",  function (event){
        var dvalue_regex = ^[+-]?([0-9]*[.])?[0-9]+$;
        var discount_value = $('#discount_value').val();
        var discount_type = $('#discount_type').val();
        if(discount_value==null || discount_value==""){
          $("#err_discount_value").text("Please Enter Discount Value.");
          $('#discount_value').focus();
          return false;
        }
        else{
          $("#err_discount_value").text("");
        }
        if (!discount_value.match(dvalue_regex) ) {
          $('#err_discount_value').text(" Please Enter Valid Discount Value. Ex(10 or 10.50)"); 
          $('#discount_value').focus();  
          return false;
        }
        else{
          $("#err_discount_value").text("");
        }
        if(discount_type == "Percentage" && discount_value > 100){
          $("#err_discount_value").text("Please Enter Discount Value Between 1 to 100");
        }
        else{
          $("#err_discount_value").text("");
        }
    });
   
}); 
</script>