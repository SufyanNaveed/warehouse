<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$p = array('admin','manager','sales_person');
if(!(in_array($this->session->userdata('type'),$p))){
  redirect('auth');
}
$this->load->view('layout/header');
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h5>
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url('auth/dashboard'); ?>"><i class="fa fa-dashboard"></i> 
                <!-- Dashboard -->
                <?php echo $this->lang->line('header_dashboard'); ?></a>
          </li>
          <li><a href="<?php echo base_url('biller'); ?>">
              <!-- Customer -->
              <?php echo $this->lang->line('customer_header'); ?>      
            </a>
        </li>
          <li class="active"><!-- Edit Customer -->
            <?php echo $this->lang->line('edit_customer_header'); ?>
          </li>
        </ol>
      </h5>    
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
      <!-- right column -->
      <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">
                <!-- Edit Customer -->
                <?php echo $this->lang->line('edit_customer_header'); ?>  
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <form role="form" id="form" method="post" action="<?php echo base_url('customer/editCustomer');?>">
                <?php foreach($data as $row){?>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="customer_name"><!-- Customer Name --> 
                        <?php echo $this->lang->line('add_customer_cname'); ?> <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo $row->customer_name; ?>">
                     <input type="hidden" name="id" value="<?php echo $row->customer_id;?>">
                    <span class="validation-color" id="err_customer_name"><?php echo form_error('customer_name'); ?></span>
                  </div>

                  <div class="form-group">
                    <label for="gstid"><!-- GSTIN --> 
                        <?php echo $this->lang->line('add_biller_gst'); ?> </label>

                    <input type="text" class="form-control" id="gstid" name="gstid" value="<?php echo $row->gstid;?>">
                    <span style="font-size: 14px; color:blue">Ex. 24XXXXXXXXXX2Z2</span>
                  </div>
                  <div class="form-group">
                    <label for="birth_date"><!-- Birth Date --> 
                        <?php echo $this->lang->line('add_customer_birth_date'); ?>
                    </label>
                    <input type="text" class="form-control datepicker" id="birth_date" name="birth_date" value="<?php echo $row->birth_date;?>">
                    <span class="validation-color" id="err_birth_date"><?php echo form_error('birth_date'); ?></span>
                  </div>
                  <div class="form-group">
                    <label for="vat_no"> VAT No 
                        <!-- <?php echo $this->lang->line('add_biller_gst'); ?> --> <span class="validation-color"></span></label>
                    <input type="text" class="form-control" id="vatno" name="vatno" value="<?php echo $row->vat_no;?>">
                    
                    <span class="validation-color" id="vatno"><?php echo form_error('vatno'); ?></span>
                  </div>

                  <div class="form-group">
                    <label for="vat_no">PAN No
                        <!-- <?php echo $this->lang->line('add_biller_gst'); ?> --> <span class="validation-color"></span></label>
                    <input type="text" class="form-control" id="panno" name="panno" value="<?php echo $row->pan_no;?>">
                    
                    <span class="validation-color" id="panno"><?php echo form_error('panno'); ?></span>
                  </div>

                  <div class="form-group">
                    <label for="tan">Tan 
                        
                        <!-- <?php echo $this->lang->line('add_customer_compname'); ?> -->
                        <span class="validation-color"></span>
                    </label>
                    <input type="text" class="form-control" id="tan" name="tan" value="<?php echo $row->tan_no;?>">
                    <span class="validation-color" id="err_tan"><?php echo form_error('tan'); ?></span>
                </div>

                <div class="form-group">
                    <label for="cstregno">Cst Reg No
                        
                        <!-- <?php echo $this->lang->line('add_customer_compname'); ?> -->
                        <span class="validation-color"></span>
                    </label>
                    <input type="text" class="form-control" id="cstregno" name="cstregno" value="<?php echo $row->cst_reg_no;?>">
                    <span class="validation-color" id="err_cstregno"><?php echo form_error('cstregno'); ?></span>
                </div>

                <div class="form-group">
                    <label for="exciseregno">Excise Reg No
                        
                        <!-- <?php echo $this->lang->line('add_customer_compname'); ?> -->
                        <span class="validation-color"></span>
                    </label>
                    <input type="text" class="form-control" id="exciseregno" name="exciseregno" value="<?php echo $row->excise_reg_no;?>">
                    <span class="validation-color" id="err_panno"><?php echo form_error('exciseregno'); ?></span>
                </div>

                <div class="form-group">
                    <label for="lbtregno">Lbt Reg No
                        
                        <!-- <?php echo $this->lang->line('add_customer_compname'); ?> -->
                        <span class="validation-color"></span>
                    </label>
                    <input type="text" class="form-control" id="lbtregno" name="lbtregno" value="<?php echo $row->lbt_reg_no;?>">
                    <span class="validation-color" id="err_lbtregno"><?php echo form_error('lbtregno'); ?></span>
                </div>

                <div class="form-group">
                    <label for="servicetaxno">Service Tax Reg No
                        
                        <!-- <?php echo $this->lang->line('add_customer_compname'); ?> -->
                        <span class="validation-color"></span>
                    </label>
                    <input type="text" class="form-control" id="servicetaxno" name="servicetaxno" value="<?php echo $row->servicetax_reg_no;?>">
                    <span class="validation-color" id="err_servicetaxno"><?php echo form_error('servicetaxno'); ?></span>
                </div>

                
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                      <label for="gstregtype">Gst Registration Type
                          <!-- <?php echo $this->lang->line('biller_lable_country'); ?> --> <span class="validation-color">*</span>
                        </label>
                      <select class="form-control select2" id="gstregtype" name="gstregtype" style="width: 100%;">
                        <option value="">
                          <!-- Select -->
                          <?php echo $this->lang->line('add_biller_select'); ?>    
                        </option>
                        <option <?php 
                                  if(isset($row->gst_registration_type)){
                                    if($row->gst_registration_type == "Registered"){
                                      echo "selected";
                                    }
                                  } 
                                ?>>Registered
                        </option>
                        <option <?php 
                                  if(isset($data[0]->gst_registration_type)){
                                    if($data[0]->gst_registration_type == "Unregistered"){
                                      echo "selected";
                                    }
                                  } 
                                ?>>Unregistered
                        </option>
                        <option <?php 
                                  if(isset($data[0]->gst_registration_type)){
                                    if($data[0]->gst_registration_type == "Composition Scheme"){
                                      echo "selected";
                                    }
                                  } 
                                ?>>Composition Scheme
                        </option>
                        <option <?php 
                                  if(isset($data[0]->gst_registration_type)){
                                    if($data[0]->gst_registration_type == "Input Service Distributor"){
                                      echo "selected";
                                    }
                                  } 
                                ?>>Input Service Distributor
                        </option>
                        <option <?php 
                                  if(isset($data[0]->gst_registration_type)){
                                    if($data[0]->gst_registration_type == "E-Commerece Operator"){
                                      echo "selected";
                                    }
                                  } 
                                ?>>E-Commerece Operator
                        </option>
                          <!-- <option>Registered</option>
                          <option>Unregistered</option>
                          <option>Composition Scheme</option>
                          <option>Input Service Distributor</option>
                          <option>E-Commerece Operator</option> -->
                      </select>
                  </div>

                  <div class="form-group">
                    <label for="company_name"><!-- Company Name --> 
                        
                        <?php echo $this->lang->line('add_customer_compname'); ?> <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo $row->company_name; ?>">
                    <span class="validation-color" id="err_company_name"><?php echo form_error('company_name'); ?></span>
                  </div>
                  <div class="form-group">
                    <label for="address"><!-- Address --> 
                        <?php echo $this->lang->line('add_biller_address'); ?> <span class="validation-color">*</span></label>
                    <textarea class="form-control" id="address" rows="4" name="address"><?php echo $row->address; ?></textarea>
                    <span class="validation-color" id="err_address"><?php echo form_error('address'); ?></span>
                  </div>

                  <div class="form-group">
                      <label for="country"><!-- Country --> 
                          <?php echo $this->lang->line('biller_lable_country'); ?> <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="country" name="country" style="width: 100%;">
                        <option value=""><!-- Select -->
                          <?php echo $this->lang->line('add_biller_select'); ?>    
                        </option>
                        <?php
                          foreach ($country as  $key) {
                        ?>
                        <option 
                          value='<?php echo $key->id ?>' 
                          <?php 
                            if(isset($row->country_id)){
                              if($key->id == $row->country_id){
                                echo "selected";
                              }
                            } 
                          ?>
                        >
                        <?php echo $key->name; ?>
                        </option>
                        <?php
                          }
                        ?>
                      </select>
                      <span class="validation-color" id="err_country"><?php echo form_error('country'); ?></span>
                    </div>
                  <div class="form-group">
                      <label for="state"><!-- State --> 
                          <?php echo $this->lang->line('add_biller_state'); ?> <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="state" name="state" style="width: 100%;">
                        <option value=""><!-- Select -->
                            <?php echo $this->lang->line('add_biller_select'); ?></option>
                        <?php
                          foreach ($state as  $key) {
                        ?>
                        <option 
                          value='<?php echo $key->id ?>' 
                          <?php 
                            if(isset($row->state_id)){
                              if($key->id == $row->state_id){
                                echo "selected";
                              }
                            } 
                          ?>
                        >
                        <?php echo $key->name; ?>
                        </option>
                      <?php
                        }
                      ?>
                      </select>
                      <span class="validation-color" id="err_state"><?php echo form_error('state'); ?></span>
                    </div>
                    <div class="form-group">
                      <label for="state_code">State Code</label>
                      <input type="text" class="form-control" id="state_code" name="state_code" value="<?php echo $row->state_code; ?>" readonly>
                      <span class="validation-color" id="err_state_code"><?php echo form_error('state_code'); ?></span>
                    </div>
                  <div class="form-group">
                      <label for="city"><!-- City --> 
                          <?php echo $this->lang->line('biller_lable_city'); ?> <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="city" name="city" style="width: 100%;">
                        <option value=""><!-- Select -->
                            <?php echo $this->lang->line('add_biller_select'); ?></option>
                        <?php
                          foreach ($city as  $key) {
                        ?>
                        <option 
                          value='<?php echo $key->id ?>' 
                          <?php 
                            if(isset($row->city_id)){
                              if($key->id == $row->city_id){
                                echo "selected";
                              }
                            } 
                          ?>
                        >
                        <?php echo $key->name; ?>
                        </option>
                        <?php
                          }
                        ?>
                      </select>
                      <span class="validation-color" id="err_city"><?php echo form_error('city'); ?></span>
                    </div>


                  <div class="form-group">
                    <label for="postal_code"><!-- Postal Code -->
                        <?php echo $this->lang->line('add_customer_code'); ?> <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo $row->postal_code; ?>">
                    <span class="validation-color" id="err_postal_code"><?php echo form_error('postal_code'); ?></span>
                  </div>

                  <div class="form-group">
                    <label for="mobile"><!-- Mobile --> 
                        <?php echo $this->lang->line('add_biller_mobile'); ?> <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $row->mobile; ?>">
                    <span class="validation-color" id="err_mobile"><?php echo form_error('mobile'); ?></span>
                  </div>

                  <div class="form-group">
                    <label for="email"><!-- email --> 
                         <?php echo $this->lang->line('biller_lable_email'); ?> <span class="validation-color">*</span></label>
                    <input type="text" class="form-control" id="email" name="email" value="<?php echo $row->email; ?>">
                    <span class="validation-color" id="err_email"><?php echo form_error('email'); ?></span>
                  </div>
                </div>
                </div>
                <div class="col-sm-12">
                  <div class="box-footer">
                    <button type="submit" id="submit" class="btn btn-info"><!-- Update -->
                      <?php echo $this->lang->line('edit_biller_btn'); ?>
                    </button>
                    <span class="btn btn-default" id="cancel" style="margin-left: 2%" onclick="cancel('biller')"><!-- Cancel -->
                      <?php echo $this->lang->line('add_user_btn_cancel'); ?></span>
                  </div>
                </div>
              <?php } ?>
              </form>
          </div>
          <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
    $this->load->view('layout/footer');
  ?>
<script>
    $('#country').change(function(){
      var id = $(this).val();
      $('#state').html('<option value="">Select</option>');
      $('#state_code').val('');
      $('#city').html('<option value="">Select</option>');
      $.ajax({
          url: "<?php echo base_url('customer/getState') ?>/"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            for(i=0;i<data.length;i++){
              $('#state').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
          }
        });
    });
</script>
<script>
    $('#state').change(function(){
      var id = $(this).val();
      var country = $('#country').val();
      $('#city').html('<option value="">Select</option>');
      $('#state_code').val('');
      $.ajax({
          url: "<?php echo base_url('customer/getCity') ?>/"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            for(i=0;i<data.length;i++){
              $('#city').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
          }
        });
      $.ajax({
          url: "<?php echo base_url('biller/getStateCode') ?>/"+id+'/'+country,
          type: "GET",
          dataType: "TEXT",
          success: function(data){
            $('#state_code').val(data);
          }
        });
    });
</script>
<script>
  $(document).ready(function(){
    $("#submit").click(function(event){
      var name_regex = /^[a-zA-Z\s]+$/;
      var sname_regex = /^[-a-zA-Z\s]+$/;
      var mobile_regex = /^[6-9][0-9]{9}$/; 
      var postal_regex = /^[1-9][0-9]{5}$/
      //indian mobile number  /^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1}){0,1}98(\s){0,1}(\-){0,1}(\s){0,1}[1-9]{1}[0-9]{7}$/
      var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var customer_name = $('#customer_name').val();
      var company_name = $('#company_name').val();
      var address = $('#address').val();
      var city = $('#city').val();
      var state = $('#state').val();
      var postal_code = $('#postal_code').val();
      var country = $('#country').val();
      var mobile = $('#mobile').val();
      var email = $('#email').val();



       if(customer_name==null || customer_name==""){
          $("#err_customer_name").text("Please Enter Customer Name.");
          return false;
        }
        else{
          $("#err_customer_name").text("");
        }
        if (!customer_name.match(name_regex) ) {
          $('#err_customer_name').text(" Please Enter Valid Customer Name ");   
          return false;
        }
        else{
          $("#err_customer_name").text("");
        }
//customer name validation complite.

        if(company_name==null || company_name==""){
          $("#err_company_name").text("Please Enter Company Name.");
          return false;
        }
        else{
          $("#err_company_name").text("");
        }
        if (!company_name.match(sname_regex) ) {
          $('#err_company_name').text(" Please Enter Valid Company Name ");   
          return false;
        }
        else{
          $("#err_company_name").text("");
        }
//company name validation complite.

        if(address==null || address==""){
          $("#err_address").text(" Please Enter Address");
          return false;
        }
        else{
          $("#err_address").text("");
        }
//Address validation complite.
        
        if(country==null || country==""){
          $("#err_country").text("Please Select Country ");
          return false;
        }
        else{
          $("#err_country").text("");
        }
//country validation complite.
      
        if(state==null || state==""){
          $("#err_state").text("Please Select State ");
          return false;
        }
        else{
          $("#err_state").text("");
        }
//state validation complite.
        
         if(city==null || city==""){
          $("#err_city").text("Please Select City ");
          return false;
        }
        else{
          $("#err_city").text("");
        }
//city validation complite.

        if(postal_code==null || postal_code==""){
          $("#err_postal_code").text("Please Enter Postal Code.");
          return false;
        }
        else{
          $("#err_postal_code").text("");
        }
        // if (!postal_code.match(postal_regex) ) {
        //   $('#err_postal_code').text(" Please Enter Valid Postal Code ");   
        //   return false;
        // }
        // else{
        //   $("#err_postal_code").text("");
        // }
//postal code validation complite.
        
        if(mobile==null || mobile==""){
          $("#err_mobile").text("Please Enter Mobile.");
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
        // if (!mobile.match(mobile_regex) ) {
        //   $('#err_mobile').text(" Please Enter Valid Mobile ");   
        //   return false;
        // }
        // else{
        //   $("#err_mobile").text("");
        // }
//mobile validation complite.
        
        if(email==null || email==""){
          $("#err_email").text("Please Enter Email.");
          return false;
        }
        else{
          $("#err_email").text("");
        }
        if (!email.match(email_regex) ) {
          $('#err_email').text(" Please Enter Valid Email Address ");   
          return false;
        }
        else{
          $("#err_email").text("");
        }
//email validation complite.

    });

    $("#customer_name").on("blur keyup",  function (event){
        var name_regex = /^[a-zA-Z\s]+$/;
        var customer_name = $('#customer_name').val();
        if(customer_name==null || customer_name==""){
          $("#err_customer_name").text("Please Enter Customer Name.");
          return false;
        }
        else{
          $("#err_customer_name").text("");
        }
        if (!customer_name.match(name_regex) ) {
          $('#err_customer_name').text(" Please Enter Valid First Name ");   
          return false;
        }
        else{
          $("#err_customer_name").text("");
        }
    });
    $("#company_name").on("blur keyup",  function (event){
        var sname_regex = /^[-a-zA-Z\s]+$/;
        var company_name = $('#company_name').val();
        $('#company_name').val(company_name);
        if(company_name==null || company_name==""){
          $("#err_company_name").text("Please Enter Company Name.");
          return false;
        }
        else{
          $("#err_company_name").text("");
        }
        if (!company_name.match(sname_regex) ) {
          $('#err_company_name').text(" Please Enter Valid Company Name ");   
          return false;
        }
        else{
          $("#err_company_name").text("");
        }
    });
    $("#address").on("blur keyup",  function (event){
        var address = $('#address').val();
        if(address==null || address==""){
          $("#err_address").text(" Please Enter Address");
          return false;
        }
        else{
          $("#err_address").text("");
        }
    });
    $("#city").change(function(event){
        var city = $('#city').val();
        $('#city').val(city);
        if(city==null || city==""){
          $("#err_city").text("Please Select City ");
          return false;
        }
        else{
          $("#err_city").text("");
        }
    });
    $("#state").change(function(event){
        var state = $('#state').val();
        $('#state').val(state);
        if(state==null || state==""){
          $("#err_state").text("Please Select State ");
          return false;
        }
        else{
          $("#err_state").text("");
        }
    });
    $("#postal_code").on("blur keyup",  function (event){
        var postal_regex = /^[1-9][0-9]{5}$/
        var postal_code = $('#postal_code').val();
        $('#postal_code').val(postal_code);
        if(postal_code==null || postal_code==""){
          $("#err_postal_code").text("Please Enter Postal Code.");
          return false;
        }
        else{
          $("#err_postal_code").text("");
        }
        // if (!postal_code.match(postal_regex) ) {
        //   $('#err_postal_code').text(" Please Enter Valid Postal Code ");   
        //   return false;
        // }
        // else{
        //   $("#err_postal_code").text("");
        // }
    });
    $("#country").change(function(event){
        var country = $('#country').val();
        $('#country').val(country);
        if(country==null || country==""){
          $("#err_country").text("Please Select Country");
          return false;
        }
        else{
          $("#err_country").text("");
        }
    });
    $("#mobile").on("blur keyup",  function (event){
        var mobile_regex = /^[6-9][0-9]{9}$/;
        var mobile = $('#mobile').val();
        $('#mobile').val(mobile);
        if(mobile==null || mobile==""){
          $("#err_mobile").text("Please Enter Mobile.");
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
        // if (!mobile.match(mobile_regex) ) {
        //   $('#err_mobile').text(" Please Enter Valid Mobile ");   
        //   return false;
        // }
        // else{
        //   $("#err_mobile").text("");
        // }
    });
    $("#email").on("blur keyup",  function (event){
        var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var email = $('#email').val();
        $('#email').val(email);
        if(email==null || email==""){
          $("#err_email").text("Please Enter Email.");
          return false;
        }
        else{
          $("#err_email").text("");
        }
        if (!email.match(email_regex) ) {
          $('#err_email').text(" Please Enter Valid Email Address ");   
          return false;
        }
        else{
          $("#err_email").text("");
        }
    });
   
}); 
</script>